import pyasn
import os
import json
'''
parpare work
First:download v6 AS and BGP repository
    pyasn_util_download.py --latestv6
then:Parse out the AS and BGP repository
    pyasn_util_convert.py --single <Downloaded RIB File> <ipasn_db_file_name>
    eg:pyasn_util_convert.py --single rib.20190924.0600.bz2 ipasn.dat.dat
'''

ansdb = pyasn.pyasn("/home/szx/dataset/ipasn.dat.dat")

data_path = "/home/szx/code/baseline/V4/IPv6_dataset.txt"
def InputAddrs(input=data_path):
    """
    从输入文件中读取IPv6地址列表，并转换为有序的地址向量序列

    Args：
        input：存储了所有种子地址的文件（.hex:不带冒号；.txt：带冒号，可压缩）
        delta:地址向量每一维度的基数

    Return:
        V：有序的地址向量序列
    """
    IPv6 = []
    count = 0
    for line in open(input):
        if line != '':
            IPv6.append(line)
            count += 1
    IPv6 = [addr.strip('\n') for addr in IPv6]

    return IPv6

# ip2as inquire
def ip2as(IPv6):
    as_number = ansdb.lookup(IPv6)[0]
    return as_number


# ip2bgp inquire
def ip2bgp(IPv6):
    bgp = ansdb.lookup(IPv6)[1]
    return bgp

BGP_dic = {}
IPv6 = InputAddrs(data_path)

for IP in IPv6:
    BGP = ip2bgp(IP)
    if BGP in BGP_dic:
        BGP_dic[BGP].append(IP)
    else:
        BGP_dic[BGP] = [IP]
BGP_path = "/home/szx/dataset/BGP_res.json"
with open(BGP_path, 'w') as f:
    json.dump(BGP_dic, f)

num_1k_1w = 0
num_1w_10w = 0
num_10w_over = 0

for BGP in BGP_dic:
    if len(BGP_dic[BGP])>1000 and len(BGP_dic[BGP])<10000 and num_1k_1w < 4:
        num_1k_1w += 1
        BGP_path = "/home/szx/dataset/BGP_1k_1w_" + str(num_1k_1w) + ".json"
        with open(BGP_path, 'w') as f:
            json.dump({BGP:BGP_dic[BGP]}, f)


    if len(BGP_dic[BGP]) > 10000 and len(BGP_dic[BGP]) < 100000 and num_1w_10w <4:
        num_1w_10w += 1
        BGP_path = "/home/szx/dataset/BGP_1w_10w_" + str(num_1w_10w) + ".json"
        with open(BGP_path, 'w') as f:
            json.dump({BGP:BGP_dic[BGP]}, f)


    if len(BGP_dic[BGP]) > 100000 and num_10w_over < 2:
        num_10w_over += 1
        BGP_path = "/home/szx/dataset/BGP_10w_over" + str(num_10w_over) + ".json"
        with open(BGP_path, 'w') as f:
            json.dump({BGP:BGP_dic[BGP]}, f)



print("Over!")



