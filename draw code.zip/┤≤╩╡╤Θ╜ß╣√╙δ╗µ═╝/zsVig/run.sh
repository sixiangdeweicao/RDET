#!/bin/bash
export NNI_PLATFORM='local'
export NNI_EXP_ID='dHo8i9LO'
export NNI_SYS_DIR='/root/nni-experiments/dHo8i9LO/trials/zsVig'
export NNI_TRIAL_JOB_ID='zsVig'
export NNI_OUTPUT_DIR='/root/nni-experiments/dHo8i9LO/trials/zsVig'
export NNI_TRIAL_SEQ_ID='0'
export MULTI_PHASE='false'
export NNI_CODE_DIR='/home/szx/code'
export CUDA_VISIBLE_DEVICES='-1'
cd $NNI_CODE_DIR
eval python3 /home/szx/code/baseline/V4_Thompsom/DynamicScan.py 2>"/root/nni-experiments/dHo8i9LO/trials/zsVig/stderr"
echo $? `date +%s%3N` >'/root/nni-experiments/dHo8i9LO/trials/zsVig/.nni/state'